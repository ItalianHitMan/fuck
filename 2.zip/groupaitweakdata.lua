local old_unit_cat = GroupAITweakData._init_unit_categories
local old_spawn_group = GroupAITweakData._init_enemy_spawn_groups
local old_task_data = GroupAITweakData._init_task_data

function GroupAITweakData:_init_unit_categories(difficulty_index)
	old_unit_cat(self, difficulty_index)
	local access_type_walk_only = {walk = true}
	local access_type_all = {walk = true, acrobatic = true}
	-- Test Cop Template
	self.unit_categories.CS_test_cop_template = {
		unit_types = {
			america = {
				Idstring("units/payday2/characters/ene_fbi_3/ene_fbi_3")
			},
			safehouse = {
				Idstring("units/payday2/characters/ene_fbi_3/ene_fbi_3")
			},
			federales = {
				Idstring("units/pd2_dlc_bex/characters/ene_swat_policia_federale/ene_swat_policia_federale")
			},
			murkywater = {
				Idstring("units/pd2_mod_mk/ene_murky_hrt_1/ene_murky_hrt_1"),
				Idstring("units/pd2_mod_mk/ene_murky_hrt_2/ene_murky_hrt_2")
			},
		},
		access = access_type_all
	}
	-- Test Agent Template
	self.unit_categories.CS_test_agent_template = {
		unit_types = {
			america = {
				Idstring("units/payday2/characters/ene_fbi_1/ene_fbi_1")
			},
			safehouse = {
				Idstring("units/payday2/characters/ene_fbi_1/ene_fbi_1")
			},
			federales = {
				Idstring("units/pd2_dlc_bex/characters/ene_policia_02/ene_policia_02")
			},
			murkywater = {
				Idstring("units/pd2_dlc_bph/characters/ene_murkywater_light/ene_murkywater_light")
			},
		},
		access = access_type_all
	}
	-- Test Female Agent Template
	self.unit_categories.CS_test_fagent_template = {
		unit_types = {
			america = {
				Idstring("units/payday2/characters/ene_fbi_2/ene_fbi_2"),
				Idstring("units/pd2_mod_nc/ene_fbi_5/ene_fbi_5")
			},
			safehouse = {
				Idstring("units/payday2/characters/ene_fbi_2/ene_fbi_2"),
				Idstring("units/pd2_mod_nc/ene_fbi_5/ene_fbi_5")
			},
			federales = {
				Idstring("units/pd2_dlc_bex/characters/ene_swat_policia_federale_city/ene_swat_policia_federale_city")
			},
			murkywater = {
				Idstring("units/pd2_dlc_des/characters/ene_murkywater_not_security_2/ene_murkywater_not_security_2")
			},
		},
		access = access_type_all
	}
	-- Test Medic Bulldozer Template
	self.unit_categories.CS_test_medic_dozer_template = {
		unit_types = {
			america = {
				Idstring("units/pd2_dlc_drm/characters/ene_bulldozer_medic/ene_bulldozer_medic")
			},
			safehouse = {
				Idstring("units/pd2_dlc_drm/characters/ene_bulldozer_medic_classic/ene_bulldozer_medic_classic")
			},
			federales = {
				Idstring("units/pd2_dlc_bex/characters/ene_swat_dozer_medic_policia_federale/ene_swat_dozer_medic_policia_federale")
			},
			murkywater = {
				Idstring("units/pd2_dlc_bph/characters/ene_murkywater_bulldozer_medic/ene_murkywater_bulldozer_medic")
			},
		},
		access = access_type_all
	}
	-- Test Taser Bulldozer Template
	self.unit_categories.CS_test_taser_dozer_template = {
		unit_types = {
			america = {
				Idstring("units/payday2/characters/ene_bulldozer_taser/ene_bulldozer_taser")
			},
			safehouse = {
				Idstring("units/payday2/characters/ene_bulldozer_taser/ene_bulldozer_taser")
			},
			federales = {
				Idstring("units/payday2/characters/ene_bulldozer_taser/ene_bulldozer_taser")
			},
			murkywater = {
				Idstring("units/payday2/characters/ene_bulldozer_taser/ene_bulldozer_taser")
			},
		},
		access = access_type_all
	}
	-- Test Minigun Bulldozer Template
	self.unit_categories.CS_test_mini_dozer_template = {
		unit_types = {
			america = {
				Idstring("units/pd2_dlc_drm/characters/ene_bulldozer_minigun_classic/ene_bulldozer_minigun_classic")
			},
			safehouse = {
				Idstring("units/pd2_dlc_drm/characters/ene_bulldozer_minigun_classic/ene_bulldozer_minigun_classic")
			},
			federales = {
				Idstring("units/pd2_dlc_bex/characters/ene_swat_dozer_policia_federale_minigun/ene_swat_dozer_policia_federale_minigun")
			},
			murkywater = {
				Idstring("units/pd2_dlc_bph/characters/ene_murkywater_bulldozer_1/ene_murkywater_bulldozer_1")
			},
		},
		access = access_type_all
	}
end

function GroupAITweakData:_init_enemy_spawn_groups(difficulty_index)
	old_spawn_group(self, difficulty_index)
	self.enemy_spawn_groups.CS_custom = {
		amount = {3, 4},
		spawn = {
			{
				unit = "CS_test_cop_template",
				freq = 0.1,
				amount_min = 2,
				tactics = self._tactics.CS_cop,
				rank = 2
			}
		}
	}
	self.enemy_spawn_groups.CS_agent_custom = {
		amount = {2, 3},
		spawn = {
			{
				unit = "CS_test_agent_template",
				freq = 0.06,
				amount_min = 1,
				tactics = self._tactics.CS_cop,
				rank = 2
			}
		}
	}
	self.enemy_spawn_groups.CS_fagent_custom = {
		amount = {2, 3},
		spawn = {
			{
				unit = "CS_test_fagent_template",
				freq = 0.05,
				amount_min = 2,
				tactics = self._tactics.CS_cop,
				rank = 3
			}
		}
	}
	self.enemy_spawn_groups.CS_medic_dozer_custom = {
		amount = {1, 1},
		spawn = {
			{
				unit = "CS_test_medic_dozer_template",
				freq = 0.015,
				amount_min = 1,
				tactics = self._tactics.CS_cop,
				rank = 4
			}
		}
	}
	self.enemy_spawn_groups.CS_taser_dozer_custom = {
		amount = {1, 1},
		spawn = {
			{
				unit = "CS_test_taser_dozer_template",
				freq = 0.0065,
				amount_min = 1,
				tactics = self._tactics.CS_cop,
				rank = 4
			}
		}
	}
	self.enemy_spawn_groups.CS_mini_dozer_custom = {
		amount = {1, 1},
		spawn = {
			{
				unit = "CS_test_mini_dozer_template",
				freq = 0.0045,
				amount_min = 1,
				tactics = self._tactics.CS_cop,
				rank = 5
			}
		}
	}
end

function GroupAITweakData:_init_task_data(difficulty_index, difficulty)
	old_task_data(self, difficulty_index, difficulty)
	self.besiege.assault.groups.CS_custom = {0.1,0.05,0.05}
	self.besiege.assault.groups.CS_agent_custom = {0.07,0.05,0.05}
	self.besiege.assault.groups.CS_fagent_custom = {0.05,0.03,0.03}
	self.besiege.assault.groups.CS_fbi_female_custom = {0.06,0.03,0.03}
	self.besiege.assault.groups.CS_medic_dozer_custom = {0.016,0.013,0.011}
	self.besiege.assault.groups.CS_taser_dozer_custom = {0.0065,0.0045,0.0035}
	self.besiege.assault.groups.CS_mini_dozer_custom = {0.0047,0.0042,0.0038}
end