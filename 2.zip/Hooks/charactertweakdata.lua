local origin_init = CharacterTweakData.init

function CharacterTweakData:init(tweak_data)
	origin_init(self, tweak_data)
	local presets = self:_presets(tweak_data)
	self:_init_police_heavygunner(presets)
	self:_init_gensec_heavygunner(presets)
	self:_init_gensec_sergeant(presets)
	self:_init_groundsniper(presets)
	self:_init_fbi_female(presets)
	self:_init_female_cop(presets)
	self:_init_city_swat_female(presets)
	self:_init_swat_female(presets)
	self:_init_fbi_swat_female(presets)
end

function CharacterTweakData:_init_fbi_swat_female(presets)
	self.fbi_swat_female = deep_clone(presets.base)
	self.fbi_swat_female.tags = {
		"law"
	}
	self.fbi_swat_female.experience = {}
	self.fbi_swat_female.weapon = presets.weapon.good
	self.fbi_swat_female.detection = presets.detection.normal
	self.fbi_swat_female.HEALTH_INIT = 8
	self.fbi_swat_female.headshot_dmg_mul = self.fbi_swat.HEALTH_INIT / 4
	self.fbi_swat_female.move_speed = presets.move_speed.very_fast
	self.fbi_swat_female.surrender_break_time = {
		6,
		10
	}
	self.fbi_swat_female.suppression = presets.suppression.hard_def
	self.fbi_swat_female.surrender = presets.surrender.easy
	self.fbi_swat_female.ecm_vulnerability = 1
	self.fbi_swat_female.ecm_hurts = {
		ears = {
			max_duration = 10,
			min_duration = 8
		}
	}
	self.fbi_swat_female.weapon_voice = "2"
	self.fbi_swat_female.experience.cable_tie = "tie_swat"
	self.fbi_swat_female.custom_voicework = "copfemale"	
	self.fbi_swat_female.speech_prefix_p1 = "fl"
	self.fbi_swat_female.speech_prefix_p2 = "n"
	self.fbi_swat_female.speech_prefix_count = 4
	self.fbi_swat_female.access = "swat"
	self.fbi_swat_female.dodge = presets.dodge.athletic
	self.fbi_swat_female.no_arrest = true
	self.fbi_swat_female.chatter = presets.enemy_chatter.swat
	self.fbi_swat_female.melee_weapon = "knife_1"
	self.fbi_swat_female.steal_loot = true
end


function CharacterTweakData:_init_swat_female(presets)
	self.swat_female = deep_clone(presets.base)
	self.swat_female.tags = {
		"law"
	}
	self.swat_female.experience = {}
	self.swat_female.weapon = presets.weapon.normal
	self.swat_female.detection = presets.detection.normal
	self.swat_female.HEALTH_INIT = 8
	self.swat_female.headshot_dmg_mul = 2
	self.swat_female.move_speed = presets.move_speed.fast
	self.swat_female.surrender_break_time = {
		6,
		10
	}
	self.swat_female.suppression = presets.suppression.hard_agg
	self.swat_female.surrender = presets.surrender.easy
	self.swat_female.ecm_vulnerability = 1
	self.swat_female.ecm_hurts = {
		ears = {
			max_duration = 10,
			min_duration = 8
		}
	}
	self.swat_female.weapon_voice = "2"
	self.swat_female.experience.cable_tie = "tie_swat"
	self.swat_female.custom_voicework = "copfemale"	
	self.swat_female.speech_prefix_p1 = "fl"
	self.swat_female.speech_prefix_p2 = "n"
	self.swat_female.speech_prefix_count = 4
	self.swat_female.access = "swat"
	self.swat_female.dodge = presets.dodge.athletic
	self.swat_female.no_arrest = true
	self.swat_female.chatter = presets.enemy_chatter.swat
	self.swat_female.melee_weapon = "knife_1"
	self.swat_female.melee_weapon_dmg_multiplier = 1
	self.swat_female.steal_loot = true
end

function CharacterTweakData:_init_city_swat_female(presets)
	self.city_swat_female = deep_clone(presets.base)
	self.city_swat_female.tags = {
		"law"
	}
	self.city_swat_female.experience = {}
	self.city_swat_female.weapon = presets.weapon.good
	self.city_swat_female.detection = presets.detection.normal
	self.city_swat_female.HEALTH_INIT = 8
	self.city_swat_female.headshot_dmg_mul = 2
	self.city_swat_female.move_speed = presets.move_speed.very_fast
	self.city_swat_female.surrender_break_time = {
		6,
		10
	}
	self.city_swat_female.suppression = presets.suppression.hard_def
	self.city_swat_female.surrender = presets.surrender.easy
	self.city_swat_female.ecm_vulnerability = 1
	self.city_swat_female.ecm_hurts = {
		ears = {
			max_duration = 10,
			min_duration = 8
		}
	}
	self.city_swat_female.weapon_voice = "2"
	self.city_swat_female.experience.cable_tie = "tie_swat"
	self.city_swat_female.silent_priority_shout = "f37"
	self.city_swat_female.custom_voicework = "copfemale"	
	self.city_swat_female.speech_prefix_p1 = "fl"
	self.city_swat_female.speech_prefix_p2 = "n"
	self.city_swat_female.speech_prefix_count = 4
	self.city_swat_female.access = "swat"
	self.city_swat_female.dodge = presets.dodge.athletic
	self.city_swat_female.chatter = presets.enemy_chatter.swat
	self.city_swat_female.melee_weapon = "knife_1"
	self.city_swat_female.steal_loot = true
	self.city_swat_female.has_alarm_pager = true
end

function CharacterTweakData:_init_female_cop(presets)
	self.female_cop = deep_clone(presets.base)
	self.female_cop.tags = {
		"law"
	}
	self.female_cop.experience = {}
	self.female_cop.weapon = presets.weapon.normal
	self.female_cop.detection = presets.detection.normal
	self.female_cop.HEALTH_INIT = 4
	self.female_cop.custom_voicework = "copfemale"	
	self.female_cop.headshot_dmg_mul = 2
	self.female_cop.move_speed = presets.move_speed.normal
	self.female_cop.surrender_break_time = {
		10,
		15
	}
	self.female_cop.suppression = presets.suppression.easy
	self.female_cop.surrender = presets.surrender.easy
	self.female_cop.ecm_vulnerability = 1
	self.female_cop.ecm_hurts = {
		ears = {
			max_duration = 10,
			min_duration = 8
		}
	}
	self.female_cop.weapon_voice = "1"
	self.female_cop.experience.cable_tie = "tie_swat"
	self.female_cop.speech_prefix_p1 = "fl"
	self.female_cop.speech_prefix_p2 = "n"
	self.female_cop.speech_prefix_count = 1
	self.female_cop.access = "cop"
	self.female_cop.silent_priority_shout = "f37"
	self.female_cop.dodge = presets.dodge.average
	self.female_cop.deathguard = true
	self.female_cop.chatter = presets.enemy_chatter.cop
	self.female_cop.melee_weapon = "baton"
	self.female_cop.steal_loot = true
end

function CharacterTweakData:_init_police_heavygunner(presets)
	self.police_heavygunner = deep_clone(presets.base)
	self.police_heavygunner.experience = {}
	self.police_heavygunner.custom_voicework = "heavygunner"	
	self.police_heavygunner.weapon = presets.weapon.normal
	self.police_heavygunner.weapon.is_shotgun_mag = {}
	self.police_heavygunner.weapon.is_shotgun_mag.aim_delay = {0.1, 0.1}
	self.police_heavygunner.weapon.is_shotgun_mag.focus_delay = 4
	self.police_heavygunner.weapon.is_shotgun_mag.focus_dis = 200
	self.police_heavygunner.weapon.is_shotgun_mag.spread = 20
	self.police_heavygunner.weapon.is_shotgun_mag.miss_dis = 40
	self.police_heavygunner.weapon.is_shotgun_mag.RELOAD_SPEED = 0.5
	self.police_heavygunner.weapon.is_shotgun_mag.melee_speed = 1
	self.police_heavygunner.weapon.is_shotgun_mag.melee_dmg = 25
	self.police_heavygunner.weapon.is_shotgun_mag.melee_retry_delay = {1, 2}
	self.police_heavygunner.weapon.is_shotgun_mag.range = {
		close = 1000,
		optimal = 2000,
		far = 5000
	}
	self.police_heavygunner.weapon.is_shotgun_mag.autofire_rounds = presets.weapon.deathwish.is_rifle.autofire_rounds
	self.police_heavygunner.weapon.is_shotgun_mag.FALLOFF = {
		{
			r = 100,
			acc = {0.6, 0.9},
			dmg_mul = 2,
			recoil = {0.4, 0.7},
			mode = {
				0,
				3,
				3,
				1
			}
		},
		{
			r = 500,
			acc = {0.6, 0.9},
			dmg_mul = 1.75,
			recoil = {0.4, 0.7},
			mode = {
				0,
				3,
				3,
				1
			}
		},
		{
			r = 1000,
			acc = {0.4, 0.8},
			dmg_mul = 1.5,
			recoil = {0.45, 0.8},
			mode = {
				1,
				2,
				2,
				0
			}
		},
		{
			r = 2000,
			acc = {0.4, 0.55},
			dmg_mul = 1.25,
			recoil = {0.45, 0.8},
			mode = {
				3,
				2,
				2,
				0
			}
		},
		{
			r = 3000,
			acc = {0.1, 0.35},
			dmg_mul = 1,
			recoil = {1, 1.2},
			mode = {
				3,
				1,
				1,
				0
			}
		}
	}
	self:_process_weapon_usage_table(self.police_heavygunner.weapon)	
	self.police_heavygunner.detection = presets.detection.normal
	self.police_heavygunner.crouch_move = false
	self.police_heavygunner.allowed_poses = {stand = true}
	self.police_heavygunner.immune_to_knock_down = true
	self.police_heavygunner.HEALTH_INIT = 80
	self.police_heavygunner.headshot_dmg_mul = 1.7
	self.police_heavygunner.move_speed = presets.move_speed.slow
	self.police_heavygunner.surrender_break_time = {10, 15}
	self.police_heavygunner.suppression = nil
	self.police_heavygunner.surrender = presets.surrender.hard
	self.police_heavygunner.ecm_vulnerability = 1
	self.police_heavygunner.ecm_hurts = {
		ears = {min_duration = 8, max_duration = 10}
	}
	self.police_heavygunner.weapon_voice = 3
	self.police_heavygunner.experience.cable_tie = tie_swat
	self.police_heavygunner.access = "swat"
	self.police_heavygunner.silent_priority_shout = f37
	self.police_heavygunner.dodge = presets.dodge.average
	self.police_heavygunner.deathguard = true
	self.police_heavygunner.chatter = presets.enemy_chatter.swat
	self.police_heavygunner.melee_weapon = knife_1
	self.police_heavygunner.steal_loot = false
end

function CharacterTweakData:_init_gensec_heavygunner(presets)
	self.gensec_heavygunner = deep_clone(presets.base)
	self.gensec_heavygunner.experience = {}
	self.gensec_heavygunner.custom_voicework = "heavygunner"
	self.gensec_heavygunner.weapon = presets.weapon.normal
	self.gensec_heavygunner.weapon.is_shotgun_mag = {}
	self.gensec_heavygunner.weapon.is_shotgun_mag.aim_delay = {0.1, 0.1}
	self.gensec_heavygunner.weapon.is_shotgun_mag.focus_delay = 4
	self.gensec_heavygunner.weapon.is_shotgun_mag.focus_dis = 200
	self.gensec_heavygunner.weapon.is_shotgun_mag.spread = 20
	self.gensec_heavygunner.weapon.is_shotgun_mag.miss_dis = 40
	self.gensec_heavygunner.weapon.is_shotgun_mag.RELOAD_SPEED = 0.5
	self.gensec_heavygunner.weapon.is_shotgun_mag.melee_speed = 1
	self.gensec_heavygunner.weapon.is_shotgun_mag.melee_dmg = 25
	self.gensec_heavygunner.weapon.is_shotgun_mag.melee_retry_delay = {1, 2}
	self.gensec_heavygunner.weapon.is_shotgun_mag.range = {
		close = 1000,
		optimal = 2000,
		far = 5000
	}
	self.gensec_heavygunner.weapon.is_shotgun_mag.autofire_rounds = presets.weapon.deathwish.is_rifle.autofire_rounds
	self.gensec_heavygunner.weapon.is_shotgun_mag.FALLOFF = {
		{
			r = 100,
			acc = {0.6, 0.9},
			dmg_mul = 2,
			recoil = {0.4, 0.7},
			mode = {
				0,
				3,
				3,
				1
			}
		},
		{
			r = 500,
			acc = {0.6, 0.9},
			dmg_mul = 1.75,
			recoil = {0.4, 0.7},
			mode = {
				0,
				3,
				3,
				1
			}
		},
		{
			r = 1000,
			acc = {0.4, 0.8},
			dmg_mul = 1.5,
			recoil = {0.45, 0.8},
			mode = {
				1,
				2,
				2,
				0
			}
		},
		{
			r = 2000,
			acc = {0.4, 0.55},
			dmg_mul = 1.25,
			recoil = {0.45, 0.8},
			mode = {
				3,
				2,
				2,
				0
			}
		},
		{
			r = 3000,
			acc = {0.1, 0.35},
			dmg_mul = 1,
			recoil = {1, 1.2},
			mode = {
				3,
				1,
				1,
				0
			}
		}
	}
	self:_process_weapon_usage_table(self.gensec_heavygunner.weapon)	
	self.gensec_heavygunner.detection = presets.detection.normal
	self.gensec_heavygunner.crouch_move = false
	self.gensec_heavygunner.allowed_poses = {stand = true}
	self.gensec_heavygunner.immune_to_knock_down = true
	self.gensec_heavygunner.HEALTH_INIT = 100
	self.gensec_heavygunner.headshot_dmg_mul = 1.7
	self.gensec_heavygunner.move_speed = presets.move_speed.slow
	self.gensec_heavygunner.surrender_break_time = {10, 15}
	self.gensec_heavygunner.suppression = nil
	self.gensec_heavygunner.surrender = presets.surrender.special
	self.gensec_heavygunner.ecm_vulnerability = 1
	self.gensec_heavygunner.ecm_hurts = {
		ears = {min_duration = 8, max_duration = 10}
	}
	self.gensec_heavygunner.weapon_voice = 3
	self.gensec_heavygunner.experience.cable_tie = tie_swat
	self.gensec_heavygunner.access = "swat"
	self.gensec_heavygunner.silent_priority_shout = f37
	self.gensec_heavygunner.dodge = presets.dodge.average
	self.gensec_heavygunner.deathguard = true
	self.gensec_heavygunner.chatter = presets.enemy_chatter.swat
	self.gensec_heavygunner.melee_weapon = knife_1
	self.gensec_heavygunner.steal_loot = false
end

function CharacterTweakData:_init_gensec_sergeant(presets)
	self.gensec_sergeant = deep_clone(presets.base)
	self.gensec_sergeant.experience = {}
	self.gensec_sergeant.weapon = presets.weapon.normal
	self.gensec_sergeant.detection = presets.detection.normal
	self.gensec_sergeant.HEALTH_INIT = 55
	self.gensec_sergeant.headshot_dmg_mul = 1.7
	self.gensec_sergeant.move_speed = presets.move_speed.fast
	self.gensec_sergeant.surrender_break_time = {10, 15}
	self.gensec_sergeant.suppression = presets.suppression.special
	self.gensec_sergeant.surrender = presets.surrender.hard
	self.gensec_sergeant.ecm_vulnerability = 1
	self.gensec_sergeant.ecm_hurts = {
		ears = {min_duration = 8, max_duration = 10}
	}
	self.gensec_sergeant.weapon_voice = 3
	self.gensec_sergeant.experience.cable_tie = tie_swat
	self.gensec_sergeant.speech_prefix_p1 = "l"
	self.gensec_sergeant.speech_prefix_p2 = n
	self.gensec_sergeant.speech_prefix_count = 5
	self.gensec_sergeant.access = "swat"
	self.gensec_sergeant.silent_priority_shout = f37
	self.gensec_sergeant.dodge = presets.dodge.athletic
	self.gensec_sergeant.deathguard = true
	self.gensec_sergeant.chatter = presets.enemy_chatter.swat
	self.gensec_sergeant.melee_weapon = knife_1
	self.gensec_sergeant.steal_loot = false
end

function CharacterTweakData:_init_groundsniper(presets)
	self.groundsniper = deep_clone(presets.base)
	self.groundsniper.tags = {"sniper"}
	self.groundsniper.no_move_and_shoot = true
	self.groundsniper.move_and_shoot_cooldown = 1
	self.groundsniper.experience = {}
	self.groundsniper.weapon = presets.weapon.sniper
	self.groundsniper.detection = presets.detection.normal
	self.groundsniper.HEALTH_INIT = 40
	self.groundsniper.headshot_dmg_mul = 2
	self.groundsniper.move_speed = presets.move_speed.fast
	self.groundsniper.shooting_death = false
	self.groundsniper.suppression = presets.suppression.easy
	self.groundsniper.ecm_vulnerability = 1
	self.groundsniper.ecm_hurts = {
		ears = {min_duration = 8, max_duration = 10}
	}
	self.groundsniper.weapon_voice = "1"
	self.groundsniper.experience.cable_tie = "tie_swat"
	self.groundsniper.speech_prefix_p1 = "l"
	self.groundsniper.speech_prefix_p2 = "n"
	self.groundsniper.speech_prefix_count = 4
	self.groundsniper.priority_shout = "f34"
	self.groundsniper.access = "swat"
	self.groundsniper.no_retreat = false
	self.groundsniper.no_arrest = true
	self.groundsniper.dodge = presets.dodge.athletic
	self.groundsniper.melee_weapon = knife_1
	self.groundsniper.chatter = presets.enemy_chatter.swat
	self.groundsniper.steal_loot = false
	self.groundsniper.rescue_hostages = false
end

function CharacterTweakData:_init_taser(presets)
	self.taser = deep_clone(presets.base)
	self.taser.tags = {"taser"}
	self.taser.experience = {}
	self.taser.weapon = {
		is_rifle = {
			aim_delay = {0.1, 0.1},
			focus_delay = 4,
			focus_dis = 200,
			spread = 20,
			miss_dis = 40,
			RELOAD_SPEED = 0.66,
			melee_speed = 0.5,
			melee_dmg = 10,
			melee_retry_delay = {1, 2},
			tase_distance = 1500,
			tase_sphere_cast_radius = 30,
			aim_delay_tase = {0, 0},
			range = {
				close = 1000,
				optimal = 2000,
				far = 5000
			},
			autofire_rounds = presets.weapon.normal.is_rifle.autofire_rounds,
			FALLOFF = {
				{
					r = 100,
					acc = {0.6, 0.9},
					dmg_mul = 3,
					recoil = {0.4, 0.7},
					mode = {
						0,
						3,
						3,
						1
					}
				},
				{
					r = 500,
					acc = {0.75, 0.95},
					dmg_mul = 2.5,
					recoil = {0.35, 0.7},
					mode = {
						0,
						3,
						3,
						1
					}
				},
				{
					r = 1000,
					acc = {0.65, 0.95},
					dmg_mul = 2,
					recoil = {0.35, 0.75},
					mode = {
						1,
						2,
						2,
						0
					}
				},
				{
					r = 2000,
					acc = {0.65, 0.8},
					dmg_mul = 1.25,
					recoil = {0.4, 1.2},
					mode = {
						3,
						2,
						2,
						0
					}
				},
				{
					r = 3000,
					acc = {0.45, 0.6},
					dmg_mul = 1,
					recoil = {1.5, 3},
					mode = {
						3,
						1,
						1,
						0
					}
				}
			}
		},
		is_shotgun_pump = {
                    aim_delay = {0.1, 0.1},
                    focus_delay = 4,
                    focus_dis = 800,
                    spread = 20,
                    miss_dis = 40,
                    RELOAD_SPEED = 0.66,
                    melee_speed = 0.5,
                    melee_dmg = 10,
                    melee_retry_delay = {1, 2},
                    tase_distance = 1500,
                    aim_delay_tase = {0, 0},
                    range = {
                        close = 1000,
                        optimal = 2000,
                        far = 5000
                    },
                    FALLOFF = {
                        {
                            r = 100,
                            acc = {0.95, 0.95},
                            dmg_mul = 3,
                            recoil = {0.4, 0.7},
                            mode = {
                                1,
                                0,
                                0,
                                0
                            }
                        },
                        {
                            r = 500,
                            acc = {0.7, 0.95},
                            dmg_mul = 2,
                            recoil = {0.4, 0.7},
                            mode = {
                                1,
                                0,
                                0,
                                0
                            }
                        },
                        {
                            r = 1000,
                            acc = {
                                0,
                                5,
                                0.8
                            },
                            dmg_mul = 1.5,
                            recoil = {0.45, 0.8},
                            mode = {
                                1,
                                0,
                                0,
                                0
                            }
                        },
                        {
                            r = 2000,
                            acc = {0.45, 0.65},
                            dmg_mul = 1,
                            recoil = {0.45, 0.8},
                            mode = {
                                1,
                                0,
                                0,
                                0
                            }
                        },
                        {
                            r = 3000,
                            acc = {0.3, 0.5},
                            dmg_mul = 0.4,
                            recoil = {1, 1.2},
                            mode = {
                                1,
                                0,
                                0,
                                0
                            }
                        }
                    }
                }
            }
	self.taser.detection = presets.detection.normal
	self.taser.HEALTH_INIT = 30
	self.taser.headshot_dmg_mul = 2
	self.taser.move_speed = presets.move_speed.fast
	self.taser.no_retreat = true
	self.taser.no_arrest = true
	self.taser.surrender = presets.surrender.special
	self.taser.ecm_vulnerability = 0.9
	self.taser.ecm_hurts = {
		ears = {min_duration = 6, max_duration = 8}
	}
	self.taser.surrender_break_time = {4, 6}
	self.taser.suppression = nil
	self.taser.weapon_voice = "3"
	self.taser.experience.cable_tie = "tie_swat"
	self.taser.speech_prefix_p1 = self._prefix_data_p1.taser()
	self.taser.speech_prefix_p2 = nil
	self.taser.speech_prefix_count = nil
	self.taser.access = "taser"
	self.taser.dodge = presets.dodge.athletic
	self.taser.priority_shout = "f32"
	self.taser.rescue_hostages = false
	self.taser.deathguard = true
	self.taser.chatter = {
		aggressive = true,
		retreat = true,
		contact = true
	}
	self.taser.announce_incomming = "incomming_taser"
	self.taser.steal_loot = nil
	self.taser.special_deaths = {}
	self.taser.special_deaths.bullet = {
		[("head"):id():key()] = {
			character_name = "bodhi",
			weapon_id = "model70",
			sequence = "kill_tazer_headshot",
			special_comment = "x01"
		}
	}
	table.insert(self._enemy_list, "taser")
end

function CharacterTweakData:_init_fbi_female(presets)
	self.fbi_female = deep_clone(presets.base)
	self.fbi_female.experience = {}
	self.fbi_female.custom_voicework = "copfemale"
	self.fbi_female.weapon = presets.weapon.normal
	self.fbi_female.detection = presets.detection.normal
	self.fbi_female.HEALTH_INIT = 24
	self.fbi_female.headshot_dmg_mul = 6
	self.fbi_female.move_speed = presets.move_speed.very_fast
	self.fbi_female.surrender_break_time = {7, 12}
	self.fbi_female.suppression = presets.suppression.hard_def
	self.fbi_female.surrender = presets.surrender.easy
	self.fbi_female.ecm_vulnerability = 1
	self.fbi_female.ecm_hurts = {
		ears = {min_duration = 8, max_duration = 10}
	}
	self.fbi_female.weapon_voice = "2"
	self.fbi_female.experience.cable_tie = "tie_swat"
	self.fbi_female.speech_prefix_p1 = "fl"
	self.fbi_female.speech_prefix_p2 = "n"
	self.fbi_female.speech_prefix_count = 1
	self.fbi_female.silent_priority_shout = "f37"
	self.fbi_female.access = "fbi"
	self.fbi_female.dodge = presets.dodge.athletic
	self.fbi_female.deathguard = true
	self.fbi_female.no_arrest = true
	self.fbi_female.chatter = presets.enemy_chatter.cop
	self.fbi_female.steal_loot = true
	table.insert(self._enemy_list, "fbi")
end

function CharacterTweakData:_multiply_all_hp(hp_mul, hs_mul)
	self.fbi_swat_female.HEALTH_INIT = self.fbi_swat_female.HEALTH_INIT * hp_mul
	self.swat_female.HEALTH_INIT = self.swat_female.HEALTH_INIT * hp_mul
	self.city_swat_female.HEALTH_INIT = self.city_swat_female.HEALTH_INIT * hp_mul
	self.female_cop.HEALTH_INIT = self.female_cop.HEALTH_INIT * hp_mul
	self.fbi.HEALTH_INIT = self.fbi.HEALTH_INIT * hp_mul
	self.swat.HEALTH_INIT = self.swat.HEALTH_INIT * hp_mul
	self.heavy_swat.HEALTH_INIT = self.heavy_swat.HEALTH_INIT * hp_mul
	self.fbi_heavy_swat.HEALTH_INIT = self.fbi_heavy_swat.HEALTH_INIT * hp_mul
	self.sniper.HEALTH_INIT = self.sniper.HEALTH_INIT * hp_mul
	self.gangster.HEALTH_INIT = self.gangster.HEALTH_INIT * hp_mul
	self.biker.HEALTH_INIT = self.biker.HEALTH_INIT * hp_mul
	self.tank.HEALTH_INIT = self.tank.HEALTH_INIT * hp_mul
	self.tank_medic.HEALTH_INIT = self.tank_medic.HEALTH_INIT * hp_mul
	self.tank_mini.HEALTH_INIT = self.tank_mini.HEALTH_INIT * hp_mul	
	self.spooc.HEALTH_INIT = self.spooc.HEALTH_INIT * hp_mul
	self.gensec_heavygunner.HEALTH_INIT = self.gensec_heavygunner.HEALTH_INIT * hp_mul
	self.police_heavygunner.HEALTH_INIT = self.police_heavygunner.HEALTH_INIT * hp_mul		
	self.shield.HEALTH_INIT = self.shield.HEALTH_INIT * hp_mul
	self.gensec_sergeant.HEALTH_INIT = self.gensec_sergeant.HEALTH_INIT * hp_mul	
	self.phalanx_minion.HEALTH_INIT = self.phalanx_minion.HEALTH_INIT * hp_mul
	self.phalanx_vip.HEALTH_INIT = self.phalanx_vip.HEALTH_INIT * hp_mul
	self.taser.HEALTH_INIT = self.taser.HEALTH_INIT * hp_mul
	self.city_swat.HEALTH_INIT = self.city_swat.HEALTH_INIT * hp_mul
	self.biker_escape.HEALTH_INIT = self.biker_escape.HEALTH_INIT * hp_mul
	self.fbi_swat.HEALTH_INIT = self.fbi_swat.HEALTH_INIT * hp_mul
	self.tank_hw.HEALTH_INIT = self.tank_hw.HEALTH_INIT * hp_mul
	self.medic.HEALTH_INIT = self.medic.HEALTH_INIT * hp_mul
	self.bolivian.HEALTH_INIT = self.bolivian.HEALTH_INIT * hp_mul
	self.bolivian_indoors.HEALTH_INIT = self.bolivian_indoors.HEALTH_INIT * hp_mul
	self.drug_lord_boss.HEALTH_INIT = self.drug_lord_boss.HEALTH_INIT * hp_mul
	self.drug_lord_boss_stealth.HEALTH_INIT = self.drug_lord_boss_stealth.HEALTH_INIT * hp_mul
	if self.security.headshot_dmg_mul then
		self.security.headshot_dmg_mul = self.security.headshot_dmg_mul * hs_mul
	end
	if self.fbi_swat_female.headshot_dmg_mul then
		self.fbi_swat_female.headshot_dmg_mul = self.fbi_swat_female.headshot_dmg_mul * hs_mul
	end	
	if self.swat_female.headshot_dmg_mul then
		self.swat_female.headshot_dmg_mul = self.swat_female.headshot_dmg_mul * hs_mul
	end		
	if self.city_swat_female.headshot_dmg_mul then
		self.city_swat_female.headshot_dmg_mul = self.city_swat_female.headshot_dmg_mul * hs_mul
	end	
	if self.female_cop.headshot_dmg_mul then
		self.female_cop.headshot_dmg_mul = self.female_cop.headshot_dmg_mul * hs_mul
	end
	if self.cop.headshot_dmg_mul then
		self.cop.headshot_dmg_mul = self.cop.headshot_dmg_mul * hs_mul
	end
	if self.fbi.headshot_dmg_mul then
		self.fbi.headshot_dmg_mul = self.fbi.headshot_dmg_mul * hs_mul
	end
	if self.swat.headshot_dmg_mul then
		self.swat.headshot_dmg_mul = self.swat.headshot_dmg_mul * hs_mul
	end
	if self.heavy_swat.headshot_dmg_mul then
		self.heavy_swat.headshot_dmg_mul = self.heavy_swat.headshot_dmg_mul * hs_mul
	end
	if self.fbi_heavy_swat.headshot_dmg_mul then
		self.fbi_heavy_swat.headshot_dmg_mul = self.fbi_heavy_swat.headshot_dmg_mul * hs_mul
	end
	if self.gensec_heavygunner.headshot_dmg_mul then
		self.gensec_heavygunner.headshot_dmg_mul = self.gensec_heavygunner.headshot_dmg_mul * hs_mul
	end
	if self.police_heavygunner.headshot_dmg_mul then
		self.police_heavygunner.headshot_dmg_mul = self.police_heavygunner.headshot_dmg_mul * hs_mul
	end		
	if self.sniper.headshot_dmg_mul then
		self.sniper.headshot_dmg_mul = self.sniper.headshot_dmg_mul * hs_mul
	end
	if self.gangster.headshot_dmg_mul then
		self.gangster.headshot_dmg_mul = self.gangster.headshot_dmg_mul * hs_mul
	end
	if self.biker.headshot_dmg_mul then
		self.biker.headshot_dmg_mul = self.biker.headshot_dmg_mul * hs_mul
	end
	if self.tank.headshot_dmg_mul then
		self.tank.headshot_dmg_mul = self.tank.headshot_dmg_mul * hs_mul
	end
	if self.tank_medic.headshot_dmg_mul then
		self.tank_medic.headshot_dmg_mul = self.tank.headshot_dmg_mul * hs_mul
	end
	if self.tank_mini.headshot_dmg_mul then
		self.tank_mini.headshot_dmg_mul = self.tank.headshot_dmg_mul * hs_mul
	end		
	if self.spooc.headshot_dmg_mul then
		self.spooc.headshot_dmg_mul = self.spooc.headshot_dmg_mul * hs_mul
	end
	if self.gensec_sergeant.headshot_dmg_mul then
		self.gensec_sergeant.headshot_dmg_mul = self.gensec_sergeant.headshot_dmg_mul * hs_mul
	end	
	if self.shield.headshot_dmg_mul then
		self.shield.headshot_dmg_mul = self.shield.headshot_dmg_mul * hs_mul
	end
	if self.phalanx_minion.headshot_dmg_mul then
		self.phalanx_minion.headshot_dmg_mul = self.phalanx_minion.headshot_dmg_mul * hs_mul
	end
	if self.phalanx_vip.headshot_dmg_mul then
		self.phalanx_vip.headshot_dmg_mul = self.phalanx_vip.headshot_dmg_mul * hs_mul
	end
	if self.taser.headshot_dmg_mul then
		self.taser.headshot_dmg_mul = self.taser.headshot_dmg_mul * hs_mul
	end
	if self.biker_escape.headshot_dmg_mul then
		self.biker_escape.headshot_dmg_mul = self.biker_escape.headshot_dmg_mul * hs_mul
	end
	if self.city_swat.headshot_dmg_mul then
		self.city_swat.headshot_dmg_mul = self.city_swat.headshot_dmg_mul * hs_mul
	end
	if self.fbi_swat.headshot_dmg_mul then
		self.fbi_swat.headshot_dmg_mul = self.fbi_swat.headshot_dmg_mul * hs_mul
	end
	if self.tank_hw.headshot_dmg_mul then
		self.tank_hw.headshot_dmg_mul = self.tank_hw.headshot_dmg_mul * hs_mul
	end
	if self.medic.headshot_dmg_mul then
		self.medic.headshot_dmg_mul = self.medic.headshot_dmg_mul * hs_mul
	end
	if self.drug_lord_boss.headshot_dmg_mul then
		self.drug_lord_boss.headshot_dmg_mul = self.drug_lord_boss.headshot_dmg_mul * hs_mul
	end
	if self.bolivian.headshot_dmg_mul then
		self.bolivian.headshot_dmg_mul = self.bolivian.headshot_dmg_mul * hs_mul
	end
	if self.bolivian_indoors.headshot_dmg_mul then
		self.bolivian_indoors.headshot_dmg_mul = self.bolivian_indoors.headshot_dmg_mul * hs_mul
	end
end

--Character Map Ahead--

function CharacterTweakData:character_map()
	local char_map = {
		basic = {
			path = "units/payday2/characters/",
			list = {
				"civ_female_bank_1",
				"civ_female_bank_manager_1",
				"civ_female_bikini_1",
				"civ_female_bikini_2",
				"civ_female_casual_1",
				"civ_female_casual_2",
				"civ_female_casual_3",
				"civ_female_casual_4",
				"civ_female_casual_5",
				"civ_female_casual_6",
				"civ_female_casual_7",
				"civ_female_casual_8",
				"civ_female_casual_9",
				"civ_female_casual_10",
				"civ_female_crackwhore_1",
				"civ_female_curator_1",
				"civ_female_curator_2",
				"civ_female_hostess_apron_1",
				"civ_female_hostess_jacket_1",
				"civ_female_hostess_shirt_1",
				"civ_female_party_1",
				"civ_female_party_2",
				"civ_female_party_3",
				"civ_female_party_4",
				"civ_female_waitress_1",
				"civ_female_waitress_2",
				"civ_female_waitress_3",
				"civ_female_waitress_4",
				"civ_female_wife_trophy_1",
				"civ_female_wife_trophy_2",
				"civ_male_bank_1",
				"civ_male_bank_2",
				"civ_male_bank_manager_1",
				"civ_male_bank_manager_3",
				"civ_male_bank_manager_4",
				"civ_male_bank_manager_5",
				"civ_male_bartender_1",
				"civ_male_bartender_2",
				"civ_male_business_1",
				"civ_male_business_2",
				"civ_male_casual_1",
				"civ_male_casual_2",
				"civ_male_casual_3",
				"civ_male_casual_4",
				"civ_male_casual_5",
				"civ_male_casual_6",
				"civ_male_casual_7",
				"civ_male_casual_8",
				"civ_male_casual_9",
				"civ_male_casual_12",
				"civ_male_casual_13",
				"civ_male_casual_14",
				"civ_male_curator_1",
				"civ_male_curator_2",
				"civ_male_curator_3",
				"civ_male_dj_1",
				"civ_male_italian_robe_1",
				"civ_male_janitor_1",
				"civ_male_janitor_2",
				"civ_male_janitor_3",
				"civ_male_meth_cook_1",
				"civ_male_party_1",
				"civ_male_party_2",
				"civ_male_party_3",
				"civ_male_pilot_1",
				"civ_male_scientist_1",
				"civ_male_miami_store_clerk_1",
				"civ_male_taxman",
				"civ_male_trucker_1",
				"civ_male_worker_1",
				"civ_male_worker_2",
				"civ_male_worker_3",
				"civ_male_worker_docks_1",
				"civ_male_worker_docks_2",
				"civ_male_worker_docks_3",
				"civ_male_dog_abuser_1",
				"civ_male_dog_abuser_2",
				"ene_biker_1",
				"ene_biker_2",
				"ene_biker_3",
				"ene_biker_4",
				"ene_bulldozer_1",
				"ene_bulldozer_2",
				"ene_bulldozer_3",
				"ene_bulldozer_4",
				"ene_city_swat_1",
				"ene_city_swat_2",
				"ene_city_swat_3",
				"ene_murkywater_1",
				"ene_murkywater_2",
				"ene_cop_1",
				"ene_cop_2",
				"ene_cop_3",
				"ene_cop_4",
				"ene_fbi_1",
				"ene_fbi_2",
				"ene_fbi_3",
				"ene_fbi_boss_1",
				"ene_fbi_female_1",
				"ene_fbi_female_2",
				"ene_fbi_female_3",
				"ene_fbi_female_4",
				"ene_fbi_heavy_1",
				"ene_fbi_office_1",
				"ene_fbi_office_2",
				"ene_fbi_office_3",
				"ene_fbi_office_4",
				"ene_fbi_swat_1",
				"ene_fbi_swat_2",
				"ene_gang_black_1",
				"ene_gang_black_2",
				"ene_gang_black_3",
				"ene_gang_black_4",
				"ene_gang_mexican_1",
				"ene_gang_mexican_2",
				"ene_gang_mexican_3",
				"ene_gang_mexican_4",
				"ene_gang_russian_1",
				"ene_gang_russian_2",
				"ene_gang_russian_3",
				"ene_gang_russian_4",
				"ene_gang_russian_5",
				"ene_gang_mobster_1",
				"ene_gang_mobster_2",
				"ene_gang_mobster_3",
				"ene_gang_mobster_4",
				"ene_gang_mobster_boss",
				"ene_guard_national_1",
				"ene_hoxton_breakout_guard_1",
				"ene_hoxton_breakout_guard_2",
				"ene_male_tgt_1",
				"ene_murkywater_1",
				"ene_murkywater_2",
				"ene_prisonguard_female_1",
				"ene_prisonguard_male_1",
				"ene_secret_service_1",
				"ene_secret_service_2",
				"ene_security_1",
				"ene_security_2",
				"ene_security_3",
				"ene_security_4",
				"ene_security_5",
				"ene_security_6",
				"ene_security_7",
				"ene_security_8",
				"ene_shield_1",
				"ene_shield_2",
				"ene_phalanx_1",
				"ene_vip_1",
				"ene_sniper_1",
				"ene_sniper_2",
				"ene_spook_1",
				"ene_swat_1",
				"ene_swat_2",
				"ene_swat_heavy_1",
				"ene_tazer_1",
				"ene_veteran_cop_1",
				"npc_old_hoxton_prisonsuit_1",
				"npc_old_hoxton_prisonsuit_2",
				"ene_medic_r870",
				"ene_medic_m4",
				"ene_city_heavy_r870",
				"ene_city_heavy_g36"
			}
		},
		dlc1 = {
			path = "units/pd2_dlc1/characters/",
			list = {
				"civ_male_bank_manager_2",
				"civ_male_casual_10",
				"civ_male_casual_11",
				"civ_male_firefighter_1",
				"civ_male_paramedic_1",
				"civ_male_paramedic_2",
				"ene_security_gensec_1",
				"ene_security_gensec_2"
			}
		},
		dlc2 = {
			path = "units/pd2_dlc2/characters/",
			list = {
				"civ_female_bank_assistant_1",
				"civ_female_bank_assistant_2"
			}
		},
		mansion = {
			path = "units/pd2_mcmansion/characters/",
			list = {
				"ene_male_hector_1",
				"ene_male_hector_2",
				"ene_hoxton_breakout_guard_1",
				"ene_hoxton_breakout_guard_2"
			}
		},
		cage = {
			path = "units/pd2_dlc_cage/characters/",
			list = {
				"civ_female_bank_2"
			}
		},
		arena = {
			path = "units/pd2_dlc_arena/characters/",
			list = {
				"civ_female_fastfood_1",
				"civ_female_party_alesso_1",
				"civ_female_party_alesso_2",
				"civ_female_party_alesso_3",
				"civ_female_party_alesso_4",
				"civ_female_party_alesso_5",
				"civ_female_party_alesso_6",
				"civ_male_party_alesso_1",
				"civ_male_party_alesso_2",
				"civ_male_alesso_booth",
				"civ_male_fastfood_1",
				"ene_guard_security_heavy_2",
				"ene_guard_security_heavy_1"
			}
		},
		kenaz = {
			path = "units/pd2_dlc_casino/characters/",
			list = {
				"civ_male_casino_1",
				"civ_male_casino_2",
				"civ_male_casino_3",
				"civ_male_casino_4",
				"ene_secret_service_1_casino",
				"civ_male_business_casino_1",
				"civ_male_business_casino_2",
				"civ_male_impersonator",
				"civ_female_casino_1",
				"civ_female_casino_2",
				"civ_female_casino_3",
				"civ_male_casino_pitboss"
			}
		},
		vip = {
			path = "units/pd2_dlc_vip/characters/",
			list = {
				"ene_vip_1",
				"ene_phalanx_1"
			}
		},
		holly = {
			path = "units/pd2_dlc_holly/characters/",
			list = {
				"civ_male_hobo_1",
				"civ_male_hobo_2",
				"civ_male_hobo_3",
				"civ_male_hobo_4",
				"ene_gang_hispanic_1",
				"ene_gang_hispanic_3",
				"ene_gang_hispanic_2"
			}
		},
		red = {
			path = "units/pd2_dlc_red/characters/",
			list = {
				"civ_female_inside_man_1"
			}
		},
		dinner = {
			path = "units/pd2_dlc_dinner/characters/",
			list = {
				"civ_male_butcher_2",
				"civ_male_butcher_1"
			}
		},
		pal = {
			path = "units/pd2_dlc_pal/characters/",
			list = {
				"civ_male_mitch"
			}
		},
		cane = {
			path = "units/pd2_dlc_cane/characters/",
			list = {
				"civ_male_helper_1",
				"civ_male_helper_2",
				"civ_male_helper_3",
				"civ_male_helper_4"
			}
		},
		berry = {
			path = "units/pd2_dlc_berry/characters/",
			list = {
				"ene_murkywater_no_light",
				"npc_locke"
			}
		},
		peta = {
			path = "units/pd2_dlc_peta/characters/",
			list = {
				"civ_male_boris"
			}
		},
		mad = {
			path = "units/pd2_dlc_mad/characters/",
			list = {
				"civ_male_scientist_01",
				"civ_male_scientist_02",
				"ene_akan_fbi_heavy_g36",
				"ene_akan_fbi_shield_sr2_smg",
				"ene_akan_fbi_spooc_asval_smg",
				"ene_akan_fbi_swat_ak47_ass",
				"ene_akan_fbi_swat_dw_ak47_ass",
				"ene_akan_fbi_swat_dw_r870",
				"ene_akan_fbi_swat_r870",
				"ene_akan_fbi_tank_r870",
				"ene_akan_fbi_tank_rpk_lmg",
				"ene_akan_fbi_tank_saiga",
				"ene_akan_cs_cop_ak47_ass",
				"ene_akan_cs_cop_akmsu_smg",
				"ene_akan_cs_cop_asval_smg",
				"ene_akan_cs_cop_r870",
				"ene_akan_cs_heavy_ak47_ass",
				"ene_akan_cs_shield_c45",
				"ene_akan_cs_swat_ak47_ass",
				"ene_akan_cs_swat_r870",
				"ene_akan_cs_swat_sniper_svd_snp",
				"ene_akan_cs_tazer_ak47_ass",
				"ene_akan_medic_ak47_ass",
				"ene_akan_medic_r870"
			}
		},
		born = {
			path = "units/pd2_dlc_born/characters/",
			list = {
				"ene_gang_biker_boss",
				"ene_biker_female_1",
				"ene_biker_female_2",
				"ene_biker_female_3",
				"npc_male_mechanic"
			}
		},
		flat = {
			path = "units/pd2_dlc_flat/characters/",
			list = {
				"npc_chavez",
				"npc_jamaican"
			}
		},
		moon = {
			path = "units/pd2_dlc_moon/characters/",
			list = {
				"civ_male_pilot_2"
			}
		},
		friend = {
			path = "units/pd2_dlc_friend/characters/",
			list = {
				"ene_bolivian_thug_outdoor_01",
				"ene_bolivian_thug_outdoor_02",
				"ene_drug_lord_boss",
				"ene_security_manager",
				"ene_thug_indoor_01",
				"ene_thug_indoor_02"
			}
		},
		gitgud = {
			path = "units/pd2_dlc_gitgud/characters/",
			list = {
				"ene_zeal_bulldozer",
				"ene_zeal_bulldozer_2",
				"ene_zeal_bulldozer_3",
				"ene_zeal_cloaker",
				"ene_zeal_swat",
				"ene_zeal_swat_heavy",
				"ene_zeal_swat_shield"
			}
		},
		help = {
			path = "units/pd2_dlc_help/characters/",
			list = {
				"ene_zeal_bulldozer_halloween"
			}
		},
		spa = {
			path = "units/pd2_dlc_spa/characters/",
			list = {
				"ene_sniper_3",
				"npc_spa",
				"npc_spa_2",
				"npc_spa_3"
			}
		},
		fish = {
			path = "units/pd2_dlc_lxy/characters/",
			list = {
				"civ_female_guest_gala_1",
				"civ_female_guest_gala_2",
				"civ_male_guest_gala_1",
				"civ_male_guest_gala_2",
				"civ_male_camera_crew_1"
			}
		},
		slu = {
			path = "units/pd2_dlc_slu/characters/",
			list = {"npc_vlad", "npc_sophia"}
		},
		run = {
			path = "units/pd2_dlc_run/characters/",
			list = {"npc_matt"}
		},
		drm = {
			path = "units/pd2_dlc_drm/characters/",
			list = {
				"ene_bulldozer_medic",
				"ene_bulldozer_minigun",
				"ene_bulldozer_minigun_classic",
				"ene_zeal_swat_heavy_sniper"
			}
		},
		dah = {
			path = "units/pd2_dlc_dah/characters/",
			list = {
				"npc_male_cfo",
				"npc_male_ralph"
			}
		},
		hvh = {
			path = "units/pd2_dlc_hvh/characters/",
			list = {
				"ene_cop_hvh_1",
				"ene_cop_hvh_2",
				"ene_cop_hvh_3",
				"ene_cop_hvh_4",
				"ene_swat_hvh_1",
				"ene_swat_hvh_2",
				"ene_fbi_hvh_1",
				"ene_fbi_hvh_2",
				"ene_fbi_hvh_3",
				"ene_spook_hvh_1",
				"ene_swat_heavy_hvh_1",
				"ene_swat_heavy_hvh_r870",
				"ene_tazer_hvh_1",
				"ene_shield_hvh_1",
				"ene_shield_hvh_2",
				"ene_medic_hvh_r870",
				"ene_medic_hvh_m4",
				"ene_bulldozer_hvh_1",
				"ene_bulldozer_hvh_2",
				"ene_bulldozer_hvh_3",
				"ene_fbi_swat_hvh_1",
				"ene_fbi_swat_hvh_2",
				"ene_fbi_heavy_hvh_1",
				"ene_fbi_heavy_hvh_r870",
				"ene_sniper_hvh_2"
			}
		},
		wwh = {
			path = "units/pd2_dlc_wwh/characters/",
			list = {
				"ene_female_crew",
				"ene_male_crew_01",
				"ene_male_crew_02",
				"ene_captain",
				"ene_locke"
			}
		},
		tag = {
			path = "units/pd2_dlc_tag/characters/",
			list = {"ene_male_commissioner"}
		},
		des = {
			path = "units/pd2_dlc_des/characters/",
			list = {
				"ene_murkywater_no_light_not_security",
				"ene_murkywater_not_security_1",
				"ene_murkywater_not_security_2",
				"ene_male_des",
				"civ_male_hazmat",
				"civ_male_des_scientist_01",
				"civ_male_des_scientist_02"
			}
		},
		nmh = {
			path = "units/pd2_dlc_nmh/characters/",
			list = {
				"civ_male_doctor_01",
				"civ_male_doctor_02",
				"civ_male_doctor_03",
				"civ_male_scrubs_01",
				"civ_male_scrubs_02",
				"civ_male_scrubs_03",
				"civ_male_scrubs_04",
				"civ_female_scrubs_01",
				"civ_female_scrubs_02",
				"civ_female_scrubs_03",
				"civ_female_scrubs_04",
				"civ_female_doctor_01",
				"civ_female_hotpants"
			}
		},
		sah = {
			path = "units/pd2_dlc_sah/characters/",
			list = {
				"civ_male_gala_guest_03",
				"civ_male_gala_guest_04",
				"civ_male_gala_guest_05",
				"civ_male_gala_guest_06",
				"civ_male_auctioneer",
				"civ_female_gala_guest_04",
				"civ_female_gala_guest_05",
				"civ_female_gala_guest_06",
				"civ_male_shacklethorn_waiter_01",
				"civ_male_shacklethorn_waiter_02",
				"civ_male_maintenance_01"
			}
		},
		skm = {
			path = "units/pd2_skirmish/characters/",
			list = {
				"civ_male_bank_manager_hostage",
				"civ_female_museum_curator_hostage",
				"civ_female_drug_lord_hostage",
				"civ_male_prisoner_hostage"
			}
		},
		bph = {
			path = "units/pd2_dlc_bph/characters/",
			list = {
				"civ_male_locke_escort",
				"civ_male_bain",
				"ene_male_bain",
				"ene_murkywater_medic",
				"ene_murkywater_medic_r870",
				"ene_murkywater_tazer",
				"ene_murkywater_cloaker",
				"ene_murkywater_bulldozer_1",
				"ene_murkywater_bulldozer_2",
				"ene_murkywater_bulldozer_3",
				"ene_murkywater_bulldozer_4",
				"ene_murkywater_bulldozer_medic",
				"ene_murkywater_shield",
				"ene_murkywater_sniper",
				"ene_murkywater_heavy",
				"ene_murkywater_heavy_shotgun",
				"ene_murkywater_heavy_g36",
				"ene_murkywater_light_city",
				"ene_murkywater_light_city_r870",
				"ene_murkywater_light_fbi_r870",
				"ene_murkywater_light_fbi",
				"ene_murkywater_light",
				"ene_murkywater_light_r870"
			}
		},
		vit = {
			path = "units/pd2_dlc_vit/characters/",
			list = {
				"ene_murkywater_secret_service"
			}
		},
		mex = {
			path = "units/pd2_dlc_mex/characters/",
			list = {
				"ene_mex_security_guard",
				"ene_mex_security_guard_2",
				"ene_mex_security_guard_3",
				"ene_mex_thug_outdoor_01",
				"ene_mex_thug_outdoor_02",
				"ene_mex_thug_outdoor_03",
				"civ_male_italian"
			}
		},		
		uno = {
			path = "units/pd2_dlc_uno/characters/",
			list = {
				"ene_shadow_cloaker_1",
				"ene_shadow_cloaker_2"
			}
		},		
		ng = {
			path = "units/pd2_mod_ng/",
			list = {
				"ene_ntl_benelli",
				"ene_ntl_groundsniper",
				"ene_ntl_heavyshotgun",
				"ene_ntl_heavyswat",
				"ene_ntl_swat_1",
				"ene_ntl_swat_2",
				"ene_ntl_swat_3",
				"ene_ntl_medic",
				"ene_ntl_shield",
				"ene_ntl_taser",
				"ene_ntl_female"
			}
		},
		mk = {
			path = "units/pd2_mod_mk/",
			list = {
				"ene_heavygunner",
				"ene_heavygunner2",
				"ene_murky_hrt_1",
				"ene_murky_hrt_2"
			}
		},		
		nc = {
			path = "units/pd2_mod_nc/",
			list = {
				"ene_gensec_heavygunner",
				"ene_gensec_sgt",
				"ene_city_swat_4",
				"ene_fbi_4",
				"ene_groundsniper_1",
				"ene_groundsniper_2",
				"ene_tazer_2",
				"ene_gensec_heavygunner2",
				"ene_fbi_5",
				"ene_heavymedic_1",
				"ene_zeal_taser",
				"ene_police_heavygunner",
				"ene_zeal_medicdozer",
				"ene_dhs_1",
				"ene_dhs_2",
				"ene_dhs_3",
				"ene_zeal_medic",
				"ene_dhs_4",
				"ene_zeal_medic_shtgn",
				"ene_police_female",
				"ene_city_swat_female",
				"ene_swat_female",
				"ene_fbi_swat_female"
			}
		},
		bex = {
			path = "units/pd2_dlc_bex/characters/",
			list = {
				"ene_swat_policia_federale",
				"ene_swat_policia_federale_r870",
				"ene_swat_policia_federale_city",
				"ene_swat_policia_federale_city_r870",
				"ene_swat_policia_federale_city_fbi",
				"ene_swat_policia_federale_city_fbi_r870",
				"ene_swat_medic_policia_federale",
				"ene_swat_medic_policia_federale_r870",
				"ene_swat_cloaker_policia_federale",
				"ene_swat_policia_sniper",
				"ene_swat_shield_policia_federale_mp9",
				"ene_swat_shield_policia_federale_c45",
				"ene_swat_tazer_policia_federale",
				"ene_swat_heavy_policia_federale",
				"ene_swat_heavy_policia_federale_r870",
				"ene_swat_heavy_policia_federale_g36",
				"ene_swat_heavy_policia_federale_fbi",
				"ene_swat_heavy_policia_federale_fbi_r870",
				"ene_swat_heavy_policia_federale_fbi_g36",
				"ene_swat_dozer_medic_policia_federale",
				"ene_swat_dozer_policia_federale_r870",
				"ene_swat_dozer_policia_federale_saiga",
				"ene_swat_dozer_policia_federale_m249",
				"ene_swat_dozer_policia_federale_minigun",
				"ene_policia_01",
				"ene_policia_02",
				"ene_bex_security_01",
				"ene_bex_security_02",
				"ene_bex_security_03",
				"ene_bex_security_suit_01",
				"ene_bex_security_suit_02",
				"ene_bex_security_suit_03",
				"civ_male_it_guy",
				"civ_male_bex_bank_manager",
				"civ_male_bex_business",
				"civ_male_mariachi_01",
				"civ_male_mariachi_02",
				"civ_male_mariachi_03",
				"civ_male_mariachi_04"
			}
		}		
	}
	return char_map
end