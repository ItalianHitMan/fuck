if not _G.newcoppers then
	_G.newcoppers = {}
	_G.newcoppers.ModPath = ModPath
	blt.xaudio.setup()
	if _G.voiceline_framework then
		_G.voiceline_framework:register_unit("copfemale")
		_G.voiceline_framework:register_unit("heavygunner")
		
		--female
		
		_G.voiceline_framework:register_line_type("copfemale", "aggressive")
		_G.voiceline_framework:register_line_type("copfemale", "buddy_died")
		_G.voiceline_framework:register_line_type("copfemale", "contact")
		_G.voiceline_framework:register_line_type("copfemale", "cover_me")
		_G.voiceline_framework:register_line_type("copfemale", "retreat")
		_G.voiceline_framework:register_line_type("copfemale", "reload")
		_G.voiceline_framework:register_line_type("copfemale", "death")
		_G.voiceline_framework:register_line_type("copfemale", "pain")
		
		--heavygunner
		
		_G.voiceline_framework:register_line_type("heavygunner", "buddy_died")
		_G.voiceline_framework:register_line_type("heavygunner", "clear")
		_G.voiceline_framework:register_line_type("heavygunner", "contact")
		_G.voiceline_framework:register_line_type("heavygunner", "death")
		_G.voiceline_framework:register_line_type("heavygunner", "gogo")
		_G.voiceline_framework:register_line_type("heavygunner", "hostage")
		_G.voiceline_framework:register_line_type("heavygunner", "pain")
		_G.voiceline_framework:register_line_type("heavygunner", "ready")
		_G.voiceline_framework:register_line_type("heavygunner", "rescue_civ")
		_G.voiceline_framework:register_line_type("heavygunner", "retreat")
		_G.voiceline_framework:register_line_type("heavygunner", "surrender")

		--female_lines
		
		for i = 1, 15 do
			_G.voiceline_framework:register_voiceline("copfemale", "aggressive", ModPath .. "assets/voiceovers/copfemale/aggressive/aggressive" .. i .. ".ogg")
		end

		for i = 1, 22 do
			_G.voiceline_framework:register_voiceline("copfemale", "buddy_died", ModPath .. "assets/voiceovers/copfemale/buddy_died/buddy_died" .. i .. ".ogg")
		end

		for i = 1, 27 do
			_G.voiceline_framework:register_voiceline("copfemale", "contact", ModPath .. "assets/voiceovers/copfemale/contact/contact" .. i .. ".ogg")
		end
		
		for i = 1, 24 do
			_G.voiceline_framework:register_voiceline("copfemale", "cover_me", ModPath .. "assets/voiceovers/copfemale/cover_me/cover_me" .. i .. ".ogg")
		end
		
		for i = 1, 8 do
			_G.voiceline_framework:register_voiceline("copfemale", "retreat", ModPath .. "assets/voiceovers/copfemale/retreat/retreat" .. i .. ".ogg")
		end
		
		for i = 1, 4 do
			_G.voiceline_framework:register_voiceline("copfemale", "reload", ModPath .. "assets/voiceovers/copfemale/reload/reload" .. i .. ".ogg")
		end

		for i = 1, 7 do
			_G.voiceline_framework:register_voiceline("copfemale", "death", ModPath .. "assets/voiceovers/copfemale/death/death" .. i .. ".ogg")
		end
		
		for i = 1, 13 do
			_G.voiceline_framework:register_voiceline("copfemale", "pain", ModPath .. "assets/voiceovers/copfemale/pain/pain" .. i .. ".ogg")
		end		
		
		--heavygunner_lines
		
		for i = 1, 19 do
			_G.voiceline_framework:register_voiceline("heavygunner", "buddy_died", ModPath .. "assets/voiceovers/heavygunner/buddy_died/buddy_died" .. i .. ".ogg")
		end
		
		for i = 1, 17 do
			_G.voiceline_framework:register_voiceline("heavygunner", "clear", ModPath .. "assets/voiceovers/heavygunner/clear/clear" .. i .. ".ogg")
		end		

		for i = 1, 49 do
			_G.voiceline_framework:register_voiceline("heavygunner", "contact", ModPath .. "assets/voiceovers/heavygunner/contact/contact" .. i .. ".ogg")
		end
		
		for i = 1, 18 do
			_G.voiceline_framework:register_voiceline("heavygunner", "gogo", ModPath .. "assets/voiceovers/heavygunner/gogo/gogo" .. i .. ".ogg")
		end
		
		for i = 1, 6 do
			_G.voiceline_framework:register_voiceline("heavygunner", "hostage", ModPath .. "assets/voiceovers/heavygunner/hostage/hostage" .. i .. ".ogg")
		end
		
		for i = 1, 5 do
			_G.voiceline_framework:register_voiceline("heavygunner", "pain", ModPath .. "assets/voiceovers/heavygunner/pain/pain" .. i .. ".ogg")
		end
		
		for i = 1, 31 do
			_G.voiceline_framework:register_voiceline("heavygunner", "ready", ModPath .. "assets/voiceovers/heavygunner/ready/ready" .. i .. ".ogg")
		end

		for i = 1, 17 do
			_G.voiceline_framework:register_voiceline("heavygunner", "rescue_civ", ModPath .. "assets/voiceovers/heavygunner/rescue_civ/rescue_civ" .. i .. ".ogg")
		end

		for i = 1, 21 do
			_G.voiceline_framework:register_voiceline("retreat", "retreat", ModPath .. "assets/voiceovers/heavygunner/retreat/retreat" .. i .. ".ogg")
		end			

		for i = 1, 17 do
			_G.voiceline_framework:register_voiceline("heavygunner", "surrender", ModPath .. "assets/voiceovers/heavygunner/surrender/surrender" .. i .. ".ogg")
		end

		for i = 1, 19 do
			_G.voiceline_framework:register_voiceline("heavygunner", "death", ModPath .. "assets/voiceovers/heavygunner/death/death" .. i .. ".ogg")
		end		
		
	else
		log("NO FRAMEWORK!!!")
	end
end